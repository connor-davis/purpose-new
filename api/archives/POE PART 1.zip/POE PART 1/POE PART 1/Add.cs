﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace POE_PART_1
{
    //child class to be called in the main through a switch-case
    class Add
    {
        //declaring private arrays 
        private List<Ingredient> ingredients;
        private List<string> steps;

        public Add() 
        { 
            ingredients= new List<Ingredient>();
            steps= new List<string>();  
        }

        public void AddIngredients()
        {
            //prompting the user to enter number of ingredients 
            Console.WriteLine("Enter the number of ingredients:");

            int numIngredients = int.Parse(Console.ReadLine());

            ingredients.Clear();

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter ingredient number{i + 1}:");
                Console.Write("Enter the name of the ingredient: ");

                string name = Console.ReadLine();

                Console.Write($"Enter the quantity of the {name}: ");

                float quantity = float.Parse(Console.ReadLine());

                Console.Write($"Enter the unit of measuerment of {name}: ");

                string unit = Console.ReadLine();

                Ingredient ing = new Ingredient(name, quantity, unit);

                ingredients.Add(ing);

                Console.WriteLine("\n----------------------");
                Console.WriteLine("Ingredients captured successfully");
                Console.WriteLine("----------------------\n");

            }

            //prompting the user to enter the number of steps 
            Console.WriteLine("Enter the number of steps required: ");

            int numSteps = int.Parse(Console.ReadLine());

            steps.Clear();

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step number{i + 1}:");

                string step = Console.ReadLine();

                steps.Add(step);

                Console.WriteLine("\n----------------------");
                Console.WriteLine("Steps captured successfully");
                Console.WriteLine("----------------------\n");
            }
        }

        public void displayRecipe()
        {
            Console.WriteLine("\n----------------------");
            Console.WriteLine("\nYour recipe details are:");
            Console.WriteLine("----------------------\n");

            Console.WriteLine("Ingredients:");

            foreach (Ingredient ing in ingredients)
            {
                Console.WriteLine($"{ing.Quantity}{ing.Unit} of {ing.Name}");
            }

            Console.WriteLine("\nSteps: ");

            for (int i = 0; i < steps.Count; i++)
            {
                    var item = steps[i];

                    Console.WriteLine($"{i + 1}:{item}");
            }
        }
        public void Scale()
        {
            Console.WriteLine("Enter the scale facor (0.5, 2, 3)");

            float scale = float.Parse(Console.ReadLine());

            foreach( Ingredient ing in ingredients)
            {
                ing.Quantity *= scale;
            }
        }
    }        
}


