﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
 
namespace POE_PART_1
{

    internal class Program
    {
        private static Add add; // REMOVE: I put this here.

        static void Main(string[] args)
        {
            //testing commits  
            //a welcome message to user the of the program
            Console.WriteLine("Welcome to your Recipe Manager!");

            //prompting the user to choose what they would like to do 
            //if a first-time user they would have to add a recipe first in order to use choices 2 till 5 
            
            while (true)
            {
                Console.WriteLine("\nWhat would you like to do?:");
                Console.WriteLine("1. Add a recipe");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale a recipe");
                Console.WriteLine("4. Re-scale a recipe");
                Console.WriteLine("5. Clear a recipe");
                Console.WriteLine("6. Exit\n ");
                Console.Write("Choice: "); 

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        {
                            add = new Add();
                            add.AddIngredients();

                            break;
                        }
                    case 2:
                        {
                            add.displayRecipe();

                            break;
                        }
                    case 3:
                        {
                            add.Scale();

                            break;
                        }
                    case 4: //reset scale
                        {
                            break;
                        }
                    case 5:
                        {
                            add = null;

                            break;
                        }
                    case 6:
                        {
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid choice.");

                            break;
                        }
                }
            }

            Console.ReadLine(); 
        }
    }
}
